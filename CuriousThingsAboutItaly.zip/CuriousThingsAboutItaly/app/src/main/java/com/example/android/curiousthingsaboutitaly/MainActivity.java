package com.example.android.curiousthingsaboutitaly;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This app tests people on some questions about the Italian culture
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * pressing the button will reset all answers to defaults
     *
     * @param view
     */
    public void resetFields(View view) {

        //first question reset
        RadioGroup group1 = (RadioGroup) findViewById(R.id.group1);
        group1.clearCheck();

        //second question reset
        RadioGroup group2 = (RadioGroup) findViewById(R.id.group2);
        group2.clearCheck();

        // third question reset
        RadioGroup group3 = (RadioGroup) findViewById(R.id.group3);
        group3.clearCheck();

        // fourth question reset
        EditText answer4_field = (EditText) findViewById(R.id.answer4_field);
        answer4_field.getText().clear();

        // fifth question reset
        RadioGroup group5 = (RadioGroup) findViewById(R.id.group5);
        group5.clearCheck();

        // sixth question reset
        RadioGroup group6 = (RadioGroup) findViewById(R.id.group6);
        group6.clearCheck();

        // seventh question reset
        CheckBox sevenA = (CheckBox) findViewById(R.id.sevenA_check_box);
        sevenA.setChecked(false);

        CheckBox sevenB = (CheckBox) findViewById(R.id.sevenB_check_box);
        sevenB.setChecked(false);

        CheckBox sevenC = (CheckBox) findViewById(R.id.sevenC_check_box);
        sevenC.setChecked(false);

        CheckBox sevenD = (CheckBox) findViewById(R.id.sevenD_check_box);
        sevenD.setChecked(false);
    }

    /** This method is called when the check button is clicked
     *
     * @return score
     */

    public void checkAnswers (View view) {

        int total = 0;

        //check first question

        RadioButton oneA = (RadioButton) findViewById(R.id.oneA_radio_button);
        if (oneA.isChecked()) {
            total += 1;
        }

        // check the second question
        RadioButton twoC = (RadioButton) findViewById(R.id.twoC_radio_button);
        if (twoC.isChecked()) {
            total += 1;
        }

        // check the third question
        RadioButton threeC = (RadioButton) findViewById(R.id.threeC_radio_button);
        if (threeC.isChecked()) {
            total += 1;
        }

        // check the fourth question
        EditText answer4 = (EditText) findViewById(R.id.answer4_field);
        String answer = answer4.getText().toString().toLowerCase().trim();
        if (answer.equals("vatican city")) {
            total += 2;
        }

        // check the fifth question
        RadioButton fiveA = (RadioButton) findViewById(R.id.fiveA_radio_button);
        if (fiveA.isChecked()) {
            total += 1;
        }

        // check the sixth question
        RadioButton sixB = (RadioButton) findViewById(R.id.sixB_radio_button);
        if (sixB.isChecked()) {
            total += 1;
        }

        //check the seventh question
        CheckBox sevenA = (CheckBox) findViewById(R.id.sevenA_check_box);
        if (sevenA.isChecked()){
            total += 0;
        }

        CheckBox sevenB = (CheckBox) findViewById(R.id.sevenB_check_box);
        if (sevenB.isChecked()){
            total += 0;
        }

        CheckBox sevenC = (CheckBox) findViewById(R.id.sevenC_check_box);
        if (sevenC.isChecked()){
            total += 1;
        }

        CheckBox sevenD = (CheckBox) findViewById(R.id.sevenD_check_box);
        if (sevenD.isChecked()){
            total += 1;
        }

        // displays the score message
        int finalScore = 9;
        String resultText = getResources().getString(R.string.you_got) + "  " + total + "   " + getString(R.string.out_of) + "  " + finalScore;

        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast,
                (ViewGroup) findViewById(R.id.custom_toast_container));

        TextView text = (TextView) layout.findViewById(R.id.text);
        text.setText(resultText);

        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.show();
    }
}