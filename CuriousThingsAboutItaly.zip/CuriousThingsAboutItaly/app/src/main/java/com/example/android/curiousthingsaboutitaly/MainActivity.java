package com.example.android.curiousthingsaboutitaly;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import static android.widget.Toast.*;

/**
 * This app tests people on some questions about the Italian culture
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * pressing the button will reset all answers to defaults
     *
     * @param view
     */
    public void resetFields(View view) {

        //first question reset
        RadioGroup group1 = (RadioGroup) findViewById(R.id.group1);
        group1.clearCheck();

        //second question reset
        RadioGroup group2 = (RadioGroup) findViewById(R.id.group2);
        group2.clearCheck();

        // third question reset
        RadioGroup group3 = (RadioGroup) findViewById(R.id.group3);
        group3.clearCheck();

        // fourth question reset
        EditText answer4_field = (EditText) findViewById(R.id.answer4_field);
        answer4_field.getText().clear();

        // fifth question reset
        RadioGroup group5 = (RadioGroup) findViewById(R.id.group5);
        group5.clearCheck();

        // sixth question reset
        RadioGroup group6 = (RadioGroup) findViewById(R.id.group6);
        group6.clearCheck();

        // seventh question reset
        CheckBox sevenA = (CheckBox) findViewById(R.id.sevenA_check_box);
        sevenA.setChecked(false);

        CheckBox sevenB = (CheckBox) findViewById(R.id.sevenB_check_box);
        sevenB.setChecked(false);

        CheckBox sevenC = (CheckBox) findViewById(R.id.sevenC_check_box);
        sevenC.setChecked(false);

        CheckBox sevenD = (CheckBox) findViewById(R.id.sevenD_check_box);
        sevenD.setChecked(false);
    }


    /**
     * This method is called when the check button is clicked
     *
     * @return score
     */

    public void checkAnswers(View view) {

        int total = 0;

        //check the first question

        RadioButton oneA = (RadioButton) findViewById(R.id.oneA_radio_button);
        if (oneA.isChecked()) {
            total ++;
        }

        // check the second question
        RadioButton twoC = (RadioButton) findViewById(R.id.twoC_radio_button);
        if (twoC.isChecked()) {
            total ++;
        }

        // check the third question
        RadioButton threeC = (RadioButton) findViewById(R.id.threeC_radio_button);
        if (threeC.isChecked()) {
            total ++;
        }

        // check the fourth question
        EditText answer4 = (EditText) findViewById(R.id.answer4_field);
        String answer = answer4.getText().toString().toLowerCase().trim();
        if (answer.equals("vatican city")) {
            total += 2;
        }

        // check the fifth question
        RadioButton fiveA = (RadioButton) findViewById(R.id.fiveA_radio_button);
        if (fiveA.isChecked()) {
            total ++;
        }

        // check the sixth question
        RadioButton sixB = (RadioButton) findViewById(R.id.sixB_radio_button);
        if (sixB.isChecked()) {
            total ++;
        }

        // check the seventh question
        CheckBox sevenA = (CheckBox) findViewById(R.id.sevenA_check_box);
        CheckBox sevenB = (CheckBox) findViewById(R.id.sevenB_check_box);
        CheckBox sevenC = (CheckBox) findViewById(R.id.sevenC_check_box);
        CheckBox sevenD = (CheckBox) findViewById(R.id.sevenD_check_box);
        boolean isSevenA = sevenA.isChecked();
        boolean isSevenB = sevenB.isChecked();
        boolean isSevenC = sevenC.isChecked();
        boolean isSevenD = sevenD.isChecked();

        if (isSevenC && isSevenD && !isSevenA && !isSevenB) {
            total+= 2;
        }
        else {
            total += 0;
        }

        // displays the score message
        int finalScore = 9;
        String resultText = getResources().getString(R.string.you_got) + " " + total + " " + getString(R.string.out_of) + "  " + finalScore;
        Toast.makeText(this, resultText, LENGTH_LONG).show();

        if (total == finalScore){
            String excellent = getResources().getString(R.string.excellent_score);
            Toast.makeText(this, excellent, LENGTH_LONG).show();
        }

        else if (total >= 6 && total <= finalScore){
            String good = getResources().getString(R.string.good_score);
            Toast.makeText(this, good, LENGTH_LONG).show();
        }

        else {
            String low = getResources().getString(R.string.low_score);
            Toast.makeText(this, low, LENGTH_LONG).show();
        }
    }
}